package com.fpapadopou.bmovie;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RatingRepository extends JpaRepository<Rating, Long> {

    /**
     * Retrieves all ratings created by the specified {@literal user}.
     *
     * @param user The user to filter.
     * @return All ratings created by the user.
     */
    List<Rating> findByUser(User user);

    /**
     * Retrieves all ratings submitted for the specified {@literal movie}.
     *
     * @param movie The movie to filter.
     * @return All the ratings for the specified movie.
     */
    List<Rating> findByMovie(Movie movie);

    /**
     * Retrieves a rating created by {@literal user} having the specified {@literal ratingId}.
     *
     * @param user The user to filter.
     * @param ratingId The rating id to look for.
     * @return A rating created by the specified user, with the specified id.
     */
    Optional<Rating> findByUserAndId(User user, Long ratingId);
}
