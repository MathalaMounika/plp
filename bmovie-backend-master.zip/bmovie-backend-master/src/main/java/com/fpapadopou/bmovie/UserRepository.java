package com.fpapadopou.bmovie;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Retrieves a user by their username.
     *
     * @param username The username to look for.
     * @return The user with the specified username (if any).
     */
    Optional<User> findByUsername(String username);
}
