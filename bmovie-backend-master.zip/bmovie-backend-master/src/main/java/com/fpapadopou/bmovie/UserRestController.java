package com.fpapadopou.bmovie;

import com.fpapadopou.bmovie.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Collection;

@RestController
@RequestMapping("/users")
public class UserRestController {

    private final UserRepository userRepository;

    @Autowired
    UserRestController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping
    Collection<User> getUsers() {
        return this.userRepository.findAll();
    }

    @PostMapping
    ResponseEntity<?> createUser(@RequestBody User input) {
        User user = this.userRepository
            .save(new User(input.getUsername(), input.getPassword()));

        URI location = ServletUriComponentsBuilder
            .fromCurrentRequest().path("/{userId}")
            .buildAndExpand(user.getId()).toUri();

        return ResponseEntity.created(location).build();
    }

    @GetMapping("/{userId}")
    User getUser(@PathVariable Long userId) {
        return this.userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException(userId));
    }
}
