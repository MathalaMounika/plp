package com.fpapadopou.bmovie;

import com.fpapadopou.bmovie.exception.MovieNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Collection;

@RestController
@RequestMapping("/movies")
public class MovieRestController {

    private final MovieRepository movieRepository;

    @Autowired
    MovieRestController(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    @GetMapping
    Collection<Movie> getMovies() {
        return this.movieRepository.findAll();
    }

    @PostMapping
    ResponseEntity<?> createMovie(@RequestBody Movie input) {
        Movie movie = this.movieRepository
                .save(new Movie(input.getTitle(), input.getDescription(), input.getThumbnailUrl()));

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest().path("/{movieId}")
                .buildAndExpand(movie.getId()).toUri();

        return ResponseEntity.created(location).build();
    }

    @GetMapping("/{movieId}")
    Movie getMovie(@PathVariable Long movieId) {
        return this.movieRepository.findById(movieId)
                .orElseThrow(() -> new MovieNotFoundException(movieId));
    }
}
