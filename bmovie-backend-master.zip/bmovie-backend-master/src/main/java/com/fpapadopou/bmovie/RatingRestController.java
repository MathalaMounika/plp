package com.fpapadopou.bmovie;

import com.fpapadopou.bmovie.exception.MovieNotFoundException;
import com.fpapadopou.bmovie.exception.RatingNotFoundException;
import com.fpapadopou.bmovie.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Collection;

@RestController
@RequestMapping("/ratings")
public class RatingRestController {

    private final UserRepository userRepository;
    private final RatingRepository ratingRepository;
    private final MovieRepository movieRepository;

    @Autowired
    RatingRestController(UserRepository userRepository,
                         RatingRepository ratingRepository,
                         MovieRepository movieRepository) {
        this.userRepository = userRepository;
        this.ratingRepository = ratingRepository;
        this.movieRepository = movieRepository;
    }

    @GetMapping
    Collection<Rating> getRatings() {
        return this.ratingRepository.findAll();
    }

    @PostMapping("/{userId}/{movieId}/{stars}")
    ResponseEntity<?> createRating(@PathVariable Long userId, @PathVariable Long movieId, @PathVariable Integer stars) {
        User user = this.validateUser(userId);
        Movie movie = this.validateMovie(movieId);
        Rating rating = this.ratingRepository
                .save(new Rating(user, movie, stars));

        URI location = ServletUriComponentsBuilder
                .fromCurrentContextPath().path("/ratings/{userId}/{ratingId}")
                .buildAndExpand(rating.getId()).toUri();

        return ResponseEntity.created(location).build();
    }

    @GetMapping("/{userId}")
    Collection<Rating> getUserRatings(@PathVariable Long userId) {
        User user = this.validateUser(userId);
        Collection<Rating> ratings = this.ratingRepository.findByUser(user);
        if (ratings.isEmpty()) {
            throw new RatingNotFoundException(user);
        }
        return ratings;
    }

    @GetMapping("/movie/{movieId}")
    Collection<Rating> getMovieRatings(@PathVariable Long movieId) {
        Movie movie = this.validateMovie(movieId);
        Collection<Rating> ratings = this.ratingRepository.findByMovie(movie);
        if (ratings.isEmpty()) {
            throw new RatingNotFoundException(movie);
        }
        return ratings;
    }

    @GetMapping("/{userId}/{ratingId}")
    Rating getRating(@PathVariable Long userId, @PathVariable Long ratingId) {
        User user = validateUser(userId);
        return this.ratingRepository.findByUserAndId(user, ratingId)
                .orElseThrow(() -> new RatingNotFoundException(user, ratingId));
    }

    private User validateUser(Long userId) {
        return this.userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
    }

    private Movie validateMovie(Long movieId) {
        return this.movieRepository.findById(movieId)
                .orElseThrow(() -> new MovieNotFoundException(movieId));
    }
}
