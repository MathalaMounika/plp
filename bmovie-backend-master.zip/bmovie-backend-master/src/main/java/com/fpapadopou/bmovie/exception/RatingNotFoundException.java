package com.fpapadopou.bmovie.exception;

import com.fpapadopou.bmovie.Movie;
import com.fpapadopou.bmovie.User;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class RatingNotFoundException extends RuntimeException {

    public RatingNotFoundException(Long ratingId) {
        super("Could not find rating '" + ratingId + "'.");
    }

    public RatingNotFoundException(User user) {
        super("User " + user.getUsername() + " has submitted no ratings.");
    }

    public RatingNotFoundException(Movie movie) {
        super("No ratings have been submitted for " + movie.getTitle() + ".");
    }

    public RatingNotFoundException(User user, Long ratingId) {
        super("Rating '" + ratingId + "' does not belong to user " + user.getUsername() + ".");
    }
}
