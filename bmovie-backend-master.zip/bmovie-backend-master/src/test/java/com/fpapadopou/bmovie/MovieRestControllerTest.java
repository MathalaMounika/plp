package com.fpapadopou.bmovie;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.util.Arrays;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = BmovieApplication.class)
@WebAppConfiguration
public class MovieRestControllerTest extends RestControllerTest {

    private MockMvc mockMvc;

    private String title = "Fancy movie title";
    private String description = "A not so long description..";
    private String thumbnailUrl = "http://example.com/image";

    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    private Movie movie;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();

        ratingRepository.deleteAllInBatch();
        movieRepository.deleteAllInBatch();
        userRepository.deleteAllInBatch();

        this.movie = movieRepository.save(new Movie(title, description, thumbnailUrl));
    }

    @Test
    public void getMovie() throws Exception {
        mockMvc.perform(get("/movies/" +  movie.getId())
                .contentType(contentType))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$.title").value(title))
                .andExpect(jsonPath("$.description").value(description))
                .andExpect(jsonPath("$.thumbnailUrl").value(thumbnailUrl));
    }

    @Test
    public void getMovies() throws Exception {
        mockMvc.perform(get("/movies")
                .contentType(contentType))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$..*").isArray())
                .andExpect(jsonPath("$..*").isNotEmpty())
                .andExpect(jsonPath("$[0].title", is(title)));
    }

    @Test
    public void createMovie() throws Exception {
        mockMvc.perform(post("/movies")
                .content(json(new Movie("Another movie", "Movie description", "http://movie.com/image")))
                .contentType(contentType))
                .andExpect(status().isCreated())
                .andExpect(header().string(
                        "Location",
                         containsString("/movies/" + movieRepository.findOne(
                                 Example.of(new Movie(
                                         "Another movie",
                                         "Movie description",
                                         "http://movie.com/image"
                                 ))).get().getId()
                         )
                ));
    }

    @Test
    public void movieNotFound() throws Exception {
        mockMvc.perform(get("/movies/1500")
                .contentType(contentType))
                .andExpect(status().isNotFound());
    }

    private String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(
                o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);
        return mockHttpOutputMessage.getBodyAsString();
    }
}
