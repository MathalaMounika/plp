package com.fpapadopou.bmovie;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.util.Arrays;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = BmovieApplication.class)
@WebAppConfiguration
public class UserRestControllerTest extends RestControllerTest {

    private MockMvc mockMvc;

    private String username = "tester";

    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    private User user;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();

        ratingRepository.deleteAllInBatch();
        movieRepository.deleteAllInBatch();
        userRepository.deleteAllInBatch();

        this.user = userRepository.save(new User(username, "password"));
    }

    @Test
    public void getUser() throws Exception {
        mockMvc.perform(get("/users/" +  user.getId())
                .contentType(contentType))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$.username").value(username));
    }

    @Test
    public void getUsers() throws Exception {
        mockMvc.perform(get("/users")
                .contentType(contentType))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$..*").isArray())
                .andExpect(jsonPath("$..*").isNotEmpty())
                .andExpect(jsonPath("$[0].username", is(username)));
    }

    @Test
    public void createUser() throws Exception {
        mockMvc.perform(post("/users")
                .content(json(new User("quentin", "passW0rd")))
                .contentType(contentType))
                .andExpect(status().isCreated())
                .andExpect(header().string(
                        "Location",
                        containsString("/users/" + userRepository.findByUsername("quentin").get().getId())
                ));
    }

    @Test
    public void userNotFound() throws Exception {
        mockMvc.perform(get("/users/1500")
                .contentType(contentType))
                .andExpect(status().isNotFound());
    }

    private String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(
                o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);
        return mockHttpOutputMessage.getBodyAsString();
    }
}
