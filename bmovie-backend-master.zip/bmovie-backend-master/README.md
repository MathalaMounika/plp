[![Build Status](https://travis-ci.org/fpapadopou/bmovie-backend.svg?branch=master)](https://travis-ci.org/fpapadopou/bmovie-backend)
[![codecov](https://codecov.io/gh/fpapadopou/bmovie-backend/branch/master/graph/badge.svg)](https://codecov.io/gh/fpapadopou/bmovie-backend)

# bmovie-backend
A movie rating API implemented with Spring Boot

### Features list (eventually):
- Admins can import new movies (title, description, etc)
- New users can register and search, rate or leave comments for movies
